# Non Nobis Solum - Automation of Soil Fertilisation Management
# V0.1.1

## Introduction

Non Nobis Solum is a Linux TUI created with the objective to make easier and faster the process of calculate a plan of fertilisation for tropical soils of Colombia. 

### Prerequisites

For the programme to function correctly, the following dependencies are required:

```bash
sudo pacman -S
```

## tests

To run the tests, use the following commands:

## Suported crops

The following crops are currently supported: corn, wheat, potato, rice, coffee, sugarcane, soya bean, tomato, bean, onion, carrot, pastures, orange, yuca, sorghum, sunflower.

## Architecture

```

```

## Required Data

- **General conditions** such as cultivable area, crop type, location and historical or projected yield.
- **Physical parameters** such as apparent density, texture and others.
- **Chemical parameters** such as the percentage of organic matter, pH and nutrients, among others.

## Methodology



## Future perspectives

This programme is designed to be like a 'Swiss army knife', a multifunctional tool to make the life of agronomists easier when it comes to soil, agroclimatology and watering. 

Future modules will include automated irrigation plans based on agroclimatic and soil hydraulic data, a vigilance agroclimatic system using NASA POWER (AG) API and the continuous improvement of this project.


## Considarations


#### Acknowledgments

## References

