# Non nobis Solum — Automatización de Planes de Fertilización
# V0.1.0

CLI en Python para Linux que automatiza la generación de planes de fertilización a partir de análisis de suelo.

## Ejecución

```bash
python3 main.py
```

El programa solicita los datos del suelo y del cultivo por consola y produce un plan completo con recomendaciones por nutriente.

## Requisitos

- Python 3.10+
- Sin dependencias externas

Para ejecutar los tests:

```bash
pip install pytest
python3 -m pytest tests/ -v
```

## Cultivos soportados

maíz, trigo, papa, arroz, café, caña, soya, tomate, frijol, cebolla, zanahoria, pasto, sorgo, naranja, yuca, girasol.

## Estructura

```
main.py             — punto de entrada CLI
entrada_datos.py    — recolección interactiva de inputs
modelo.py           — dataclass Soildata (35 campos)
config.py           — tabla de cultivos y fuentes de fertilizante
n.py                — módulo nitrógeno
p.py                — módulo fósforo
k.py                — módulo potasio
s.py                — módulo azufre
ca.py               — módulo calcio
mg.py               — módulo magnesio
minor_elements.py   — micronutrientes (Fe, Mn, Zn, Cu, B, Mo)
tests/test_n.py     — tests unitarios del módulo N
```

## Datos de entrada requeridos

- Condiciones generales: cultivo, área (ha), rendimiento esperado (t/ha), riego, tipo de fertilización (absorcion/extraccion), altitud, precipitación
- Parámetros físicos: DAP, DR, capa arable, textura, porosidad, CC, PMP, EE
- Parámetros hidráulicos: Kfs, infiltración
- Parámetros químicos: MO%, pH, CE, N, P, K, S, Ca, Mg, Fe, Mn, Zn, Cu, B, Si, Mo, CIC, saturación de bases

## Notas agronómicas

- N calculado a partir de materia orgánica (mineralización anual ~1.5%)
- P disponible: P Olsen (mg/kg)
- K intercambiable: cmol(+)/kg, convertido a mg/kg × 391
- Ca y Mg: corrección por saturación de CIC (meta 70% Ca, 15% Mg)
- Eficiencias de N: 40–70% según textura y riego
- Los coeficientes de absorción/extracción son valores de referencia y deben calibrarse con tablas locales
